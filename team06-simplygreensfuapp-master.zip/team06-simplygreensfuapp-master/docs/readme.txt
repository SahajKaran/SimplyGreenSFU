Basic Guidelines
Descriptive identifier names.
First letter of class names is capitalized.
Start all variables, objects and method names with a lower-case letter.
Constant varaibles names are all caps seperated by undescores.
There should be comments on all classes.

Notes on comments
Comments should not be enclosed in large boxes drawn with asterisks or other characters.
Comments should never include special characters such as form-feed and backspace.
